from __future__ import annotations
import ast
import csv
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_DIR = Path(os.getenv("AI_NOTEBOOK_HOME", Path.home() / "AI_Code_Explanation_App"))
DATA_DIR = APP_DIR / "data"
REPORT_DIR = APP_DIR / "reports"
DATA_FILE = DATA_DIR / "records.json"


def now():
    return datetime.now(timezone.utc).isoformat()


def load_records():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        return []
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        try:
            DATA_FILE.rename(DATA_FILE.with_suffix(".corrupt.json"))
        except OSError:
            pass
        return []


def save_records(records):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = DATA_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(DATA_FILE)
    with (DATA_DIR / "records.csv").open("w", newline="", encoding="utf-8") as f:
        fields = ["id", "title", "category", "test_status", "status",
                  "created_at", "explanation", "suggestions", "code"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in records:
            writer.writerow({**r, "suggestions": " | ".join(r.get("suggestions", []))})


def analyze(source):
    if not source.strip():
        return False, "No Python code entered.", "Paste code into the editor first.", []
    if len(source) > 50000:
        return False, "Code exceeds the 50,000 character limit.", "", []
    try:
        tree = ast.parse(source)
        compile(source, "<submitted-code>", "exec")
    except SyntaxError as exc:
        return False, f"Syntax error on line {exc.lineno}: {exc.msg}", \
               "The code could not be parsed. Correct the syntax and review again.", \
               ["Check brackets, indentation, colons, and quotation marks."]
    funcs = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
    imports = [n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
    names = [n.id for n in ast.walk(tree) if isinstance(n, ast.Name)]
    explanation = f"This program has {len(source.splitlines())} lines. "
    if funcs:
        explanation += "It defines function(s): " + ", ".join(x.name for x in funcs[:10]) + ". "
    if classes:
        explanation += "It defines class(es): " + ", ".join(x.name for x in classes[:10]) + ". "
    if imports:
        explanation += f"It contains {len(imports)} import statement(s). "
    if not funcs and not classes:
        explanation += "Its logic is written as top-level statements. "
    suggestions = []
    if not ast.get_docstring(tree):
        suggestions.append("Add a module docstring explaining the program's purpose.")
    if any(not ast.get_docstring(f) for f in funcs):
        suggestions.append("Add docstrings to functions.")
    if "print" in names:
        suggestions.append("Separate display/output code from reusable business logic where practical.")
    if any(isinstance(n, ast.ExceptHandler) and n.type is None for n in ast.walk(tree)):
        suggestions.append("Replace bare except clauses with specific exception types.")
    if any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "eval"
           for n in ast.walk(tree)):
        suggestions.append("Review eval() usage; safer parsing alternatives are usually preferable.")
    if not suggestions:
        suggestions.append("No basic structural concerns detected. Add tests for important edge cases.")
    return True, "Python syntax and compilation checks passed.", explanation, suggestions


class CodeNotebookApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Code Explanation Notebook")
        self.geometry("1180x780")
        self.minsize(900, 620)
        self.records = load_records()
        self.current_id = None
        self._style()
        self._build()
        self.refresh_list()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Sub.TLabel", foreground="#536273")
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Treeview", rowheight=27, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _build(self):
        header = ttk.Frame(self, padding=(18, 14))
        header.pack(fill="x")
        ttk.Label(header, text="AI Code Explanation Notebook", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Review • Validate • Document • Search • Report",
                  style="Sub.TLabel").pack(anchor="w", pady=(3, 0))

        toolbar = ttk.Frame(self, padding=(16, 0, 16, 10))
        toolbar.pack(fill="x")
        for label, command in [
            ("New", self.new_record), ("Review & Save", self.review_save),
            ("Run Static Check", self.check_code), ("Import CSV", self.import_csv),
            ("Export Report", self.export_report), ("Analytics", self.analytics)
        ]:
            ttk.Button(toolbar, text=label, command=command,
                       style="Accent.TButton" if label == "Review & Save" else "TButton").pack(side="left", padx=(0, 7))

        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        left = ttk.Frame(body, padding=8)
        right = ttk.Frame(body, padding=8)
        body.add(left, weight=1)
        body.add(right, weight=3)

        ttk.Label(left, text="Saved records", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        search_row = ttk.Frame(left)
        search_row.pack(fill="x", pady=8)
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_row, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True)
        search_entry.bind("<KeyRelease>", lambda _e: self.refresh_list())
        ttk.Button(search_row, text="Clear", command=lambda: self.search_var.set("")).pack(side="left", padx=4)
        self.tree = ttk.Treeview(left, columns=("category", "check"), show="tree headings")
        self.tree.heading("#0", text="Title")
        self.tree.heading("category", text="Category")
        self.tree.heading("check", text="Check")
        self.tree.column("#0", width=160)
        self.tree.column("category", width=90)
        self.tree.column("check", width=75)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.select_record)
        ttk.Button(left, text="Delete selected", command=self.delete_record).pack(fill="x", pady=8)

        form = ttk.Frame(right)
        form.pack(fill="x")
        ttk.Label(form, text="Title").grid(row=0, column=0, sticky="w", padx=(0, 6), pady=4)
        self.title_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.title_var).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Category").grid(row=1, column=0, sticky="w", padx=(0, 6), pady=4)
        self.category_var = tk.StringVar(value="General")
        ttk.Entry(form, textvariable=self.category_var).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Status").grid(row=2, column=0, sticky="w", padx=(0, 6), pady=4)
        self.status_var = tk.StringVar(value="OPEN")
        ttk.Combobox(form, textvariable=self.status_var, values=["OPEN", "COMPLETED"],
                     state="readonly").grid(row=2, column=1, sticky="ew", pady=4)
        form.columnconfigure(1, weight=1)

        ttk.Label(right, text="Python code (maximum 50,000 characters)",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 4))
        code_frame = ttk.Frame(right)
        code_frame.pack(fill="both", expand=True)
        self.code_text = tk.Text(code_frame, wrap="none", undo=True, font=("Consolas", 10),
                                 height=15, padx=8, pady=8)
        yscroll = ttk.Scrollbar(code_frame, orient="vertical", command=self.code_text.yview)
        xscroll = ttk.Scrollbar(code_frame, orient="horizontal", command=self.code_text.xview)
        self.code_text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.code_text.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        code_frame.rowconfigure(0, weight=1)
        code_frame.columnconfigure(0, weight=1)

        ttk.Label(right, text="Explanation and review results",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 4))
        self.result_text = tk.Text(right, height=8, wrap="word", state="disabled",
                                   font=("Segoe UI", 9), padx=8, pady=6)
        self.result_text.pack(fill="x")
        self.status_bar = ttk.Label(self, text="Ready. Local analysis is available offline.",
                                    relief="sunken", anchor="w", padding=6)
        self.status_bar.pack(fill="x", side="bottom")

    def set_results(self, text):
        self.result_text.configure(state="normal")
        self.result_text.delete("1.0", "end")
        self.result_text.insert("1.0", text)
        self.result_text.configure(state="disabled")

    def refresh_list(self):
        term = self.search_var.get().casefold()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for record in self.records:
            hay = " ".join([record.get("title", ""), record.get("category", ""),
                            record.get("code", ""), record.get("explanation", "")]).casefold()
            if term in hay:
                self.tree.insert("", "end", iid=record["id"],
                                 text=record.get("title", "Untitled"),
                                 values=(record.get("category", ""), record.get("test_status", "NOT_RUN")))

    def get_code(self):
        return self.code_text.get("1.0", "end-1c")

    def check_code(self):
        ok, message, explanation, suggestions = analyze(self.get_code())
        self.set_results(message + "\n\n" + explanation + "\n\nSuggestions:\n" +
                         "\n".join("• " + s for s in suggestions))
        self.status_bar.config(text="Static check passed." if ok else "Static check failed.")
        return ok, message, explanation, suggestions

    def review_save(self):
        title = self.title_var.get().strip()
        category = self.category_var.get().strip()
        code = self.get_code()
        if not title or not category or not code.strip():
            messagebox.showwarning("Missing information", "Enter a title, category, and Python code.")
            return
        if len(title) > 120 or len(category) > 60 or len(code) > 50000:
            messagebox.showwarning("Input too long", "Title max 120, category max 60, code max 50,000 characters.")
            return
        ok, message, explanation, suggestions = self.check_code()
        record = next((r for r in self.records if r["id"] == self.current_id), None)
        if record is None:
            record = {"id": str(uuid.uuid4()), "created_at": now()}
            self.records.append(record)
        record.update({
            "title": title, "category": category, "code": code,
            "explanation": explanation, "suggestions": suggestions,
            "test_status": "PASSED" if ok else "FAILED",
            "test_details": message, "status": self.status_var.get(),
            "updated_at": now()
        })
        self.current_id = record["id"]
        save_records(self.records)
        self.refresh_list()
        self.tree.selection_set(self.current_id)
        self.status_bar.config(text=f"Saved: {title}")
        messagebox.showinfo("Saved", "Code review record saved successfully.")

    def new_record(self):
        self.current_id = None
        self.title_var.set("")
        self.category_var.set("General")
        self.status_var.set("OPEN")
        self.code_text.delete("1.0", "end")
        self.set_results("Enter Python code, then choose Run Static Check or Review & Save.")
        self.tree.selection_remove(self.tree.selection())
        self.status_bar.config(text="New record.")

    def select_record(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return
        record = next((r for r in self.records if r["id"] == selected[0]), None)
        if not record:
            return
        self.current_id = record["id"]
        self.title_var.set(record.get("title", ""))
        self.category_var.set(record.get("category", "General"))
        self.status_var.set(record.get("status", "OPEN"))
        self.code_text.delete("1.0", "end")
        self.code_text.insert("1.0", record.get("code", ""))
        self.set_results(
            f"{record.get('test_details', '')}\n\n{record.get('explanation', '')}\n\nSuggestions:\n" +
            "\n".join("• " + x for x in record.get("suggestions", []))
        )

    def delete_record(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select a record", "Choose a saved record first.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete the selected record?"):
            return
        self.records = [r for r in self.records if r["id"] != selected[0]]
        save_records(self.records)
        self.new_record()
        self.refresh_list()

    def analytics(self):
        total = len(self.records)
        passed = sum(r.get("test_status") == "PASSED" for r in self.records)
        failed = sum(r.get("test_status") == "FAILED" for r in self.records)
        open_count = sum(r.get("status") == "OPEN" for r in self.records)
        rate = (passed / (passed + failed) * 100) if passed + failed else 0
        messagebox.showinfo("Executive analytics",
            f"Total records: {total}\nPassed: {passed}\nFailed: {failed}\n"
            f"Not checked: {total-passed-failed}\nPass rate: {rate:.1f}%\nOpen items: {open_count}")

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        imported, errors = [], []
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames or not {"title", "category", "code"}.issubset(reader.fieldnames):
                    raise ValueError("CSV requires title, category, and code columns.")
                for line, row in enumerate(reader, 2):
                    title, category, code = (row.get("title") or "").strip(), (row.get("category") or "").strip(), row.get("code") or ""
                    if not title or not category or not code.strip():
                        errors.append(f"Row {line}: title, category and code are required.")
                        continue
                    ok, msg, explanation, suggestions = analyze(code)
                    imported.append({
                        "id": str(uuid.uuid4()), "title": title[:120], "category": category[:60],
                        "code": code[:50000], "explanation": explanation, "suggestions": suggestions,
                        "test_status": "PASSED" if ok else "FAILED", "test_details": msg,
                        "status": "OPEN", "created_at": now(), "updated_at": now()
                    })
            self.records.extend(imported)
            save_records(self.records)
            self.refresh_list()
            summary = f"Imported {len(imported)} row(s)."
            if errors:
                summary += "\n\nSkipped rows:\n" + "\n".join(errors[:20])
            messagebox.showinfo("CSV import", summary)
        except (OSError, ValueError, csv.Error) as exc:
            messagebox.showerror("Import failed", str(exc))

    def export_report(self):
        if not self.records:
            messagebox.showinfo("No data", "Add records before exporting a report.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".md",
            filetypes=[("Markdown report", "*.md"), ("CSV report", "*.csv"), ("Text audit log", "*.txt")])
        if not path:
            return
        ext = Path(path).suffix.lower()
        try:
            if ext == ".csv":
                with open(path, "w", newline="", encoding="utf-8") as f:
                    fields = ["id", "title", "category", "test_status", "status", "explanation", "code"]
                    writer = csv.DictWriter(f, fieldnames=fields)
                    writer.writeheader()
                    writer.writerows({k: r.get(k, "") for k in fields} for r in self.records)
            else:
                lines = ["# AI Code Explanation Notebook — Executive Report", "",
                         f"Generated: {now()}", f"Total records: {len(self.records)}", ""]
                for r in self.records:
                    lines += [f"## {r.get('title')}", f"- Category: {r.get('category')}",
                              f"- Check: {r.get('test_status')}", f"- Status: {r.get('status')}",
                              "", r.get("explanation", ""), "", "Suggestions:"]
                    lines += ["- " + s for s in r.get("suggestions", [])]
                    lines += ["", "```python", r.get("code", ""), "```", ""]
                Path(path).write_text("\n".join(lines), encoding="utf-8")
            messagebox.showinfo("Export complete", f"Report saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))

    def on_close(self):
        save_records(self.records)
        self.destroy()


def main():
    app = CodeNotebookApp()
    app.mainloop()


if __name__ == "__main__":
    main()
