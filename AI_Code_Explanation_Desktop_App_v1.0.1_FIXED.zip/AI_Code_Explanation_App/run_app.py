"""Convenience launcher for the AI Code Explanation desktop application."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from ai_code_app.main import main

if __name__ == "__main__":
    main()
