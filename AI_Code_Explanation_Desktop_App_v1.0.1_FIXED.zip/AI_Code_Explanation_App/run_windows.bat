@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0src"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 -m ai_code_app.main
) else (
    python -m ai_code_app.main
)
if errorlevel 1 (
    echo.
    echo Application could not start. Check that Python 3.10+ and Tkinter are installed.
    pause
)
endlocal
