# AI Code Explanation Notebook — Desktop Application Build

This ZIP contains the **actual runnable desktop application source**, not a report or a notebook document.

## Run it

Requires Python 3.10+ and Tkinter (normally included with standard Python installers).

### Windows
1. Extract the ZIP.
2. Open the extracted folder.
3. Double-click `run_windows.bat`.

Or from the folder terminal:
```bash
python run_app.py
```

### macOS / Linux
```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

If launching by module name, set the source folder on the Python path:
```bash
# Windows PowerShell
$env:PYTHONPATH = "$PWD/src"
python -m ai_code_app.main

# macOS / Linux
PYTHONPATH=src python -m ai_code_app.main
```

## Application capabilities
- Desktop GUI with code editor and saved-record list
- Static Python syntax/compile validation
- Local code structure explanation and improvement suggestions
- JSON persistence plus CSV mirror
- Keyword search, record status, delete and update
- CSV bulk import with row-level validation
- Executive analytics and Markdown/TXT/CSV exports

## Safety
The application does **not execute submitted code**. It uses Python AST parsing and compilation checks only. This avoids running untrusted snippets on the user's computer.

## Data
Records are saved to `~/AI_Code_Explanation_App/data/records.json` and `records.csv`. The application creates this directory automatically.

## Notes
The reference brief calls for an interactive terminal interface and describes a GUI as an optional enhancement. This build provides a desktop GUI as the primary interface. It is a local single-user desktop application; multi-user hosting, authentication, and managed deployment are not included.
